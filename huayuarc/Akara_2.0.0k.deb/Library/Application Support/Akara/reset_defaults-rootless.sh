#!/bin/sh

cp /var/jb/Library/Application\ Support/Akara/ModuleConfiguration_Akara.plist /var/jb/var/mobile/Library/ControlCenter/
cp /var/jb/Library/Application\ Support/Akara/com.tr1roo.akara.providedakaramodule.0.plist /var/jb/var/mobile/Library/Preferences/
cp /var/jb/Library/Application\ Support/Akara/com.tr1roo.akara.providedakaramodule.1.plist /var/jb/var/mobile/Library/Preferences/
cp /var/jb/Library/Application\ Support/Akara/com.tr1roo.akara.providedakaraverticalmodule.0.plist /var/jb/var/mobile/Library/Preferences/